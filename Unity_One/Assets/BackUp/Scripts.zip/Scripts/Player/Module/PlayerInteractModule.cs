using Unity.Netcode;
using UnityEngine;

public class PlayerInteractModule : NetworkBehaviour
{
    private const float RequestedPosePositionEpsilon = 0.0005f;
    private const float RequestedPoseRotationEpsilon = 0.1f;
    private const float RequestedPoseScaleEpsilon = 0.0005f;

    [Header("Raycast")]
    [Tooltip("오너가 사용하는 카메라")]
    [SerializeField] private Camera ownerCamera;

    [Tooltip("픽업 레이캐스트 거리")]
    [SerializeField] private float pickupDistance = 6f;

    [Tooltip("픽업 가능한 레이어 마스크")]
    [SerializeField] private LayerMask pickupMask;

    [Header("Hand")]
    [Tooltip("오른손 소켓(WeaponPoint). 비어있으면 휴머노이드 RightHand를 자동 탐색")]
    [SerializeField] private Transform rightHandBone;

    [Tooltip("왼손 소켓. 비어있으면 휴머노이드 LeftHand를 자동 탐색")]
    [SerializeField] private Transform leftHandBone;

    [Tooltip("아이템을 손에 붙일 때 기본 로컬 위치 오프셋")]
    [SerializeField] private Vector3 defaultHeldLocalPosition;

    [Tooltip("아이템을 손에 붙일 때 기본 로컬 회전 오프셋(오일러)")]
    [SerializeField] private Vector3 defaultHeldLocalEulerAngles;

    [Tooltip("아이템을 손에 붙일 때 기본 로컬 스케일")]
    [SerializeField] private Vector3 defaultHeldLocalScale = Vector3.one;

    [Header("Held Visual")]
    [Tooltip("장착 비주얼 프리팹이 있으면 월드 네트워크 아이템 대신 로컬 비주얼을 손에 붙입니다")]
    [SerializeField] private bool preferLocalHeldVisual = true;

    [Tooltip("로컬 장착 비주얼이 없을 때만 기존 월드 아이템 손부착 방식을 사용합니다")]
    [SerializeField] private bool fallbackToWorldAttachWhenNoVisual = true;

    [Tooltip("픽업 중 캐릭터 컨트롤러 충돌을 끄고 싶으면 체크(월드 아이템 부착 fallback일 때만 적용)")]
    [SerializeField] private bool disableCharacterControllerWhilePickingUp = true;

    [Header("Pickup Timing")]
    [Tooltip("애니 이벤트가 누락되었을 때 자동으로 붙이는 대기 시간(초)")]
    [SerializeField] private float pickupPendingTime = 1.5f;

    [Header("Drop/Throw")]
    [Tooltip("드랍/던지기 전방 힘")]
    [SerializeField] private float throwForwardForce = 5f;

    [Tooltip("드랍/던지기 위쪽 힘")]
    [SerializeField] private float throwUpForce = 2f;

    [Header("Drop From Hand")]
    [Tooltip("드랍 시 손 위치에서 플레이어 전방으로 살짝 밀어 겹침을 줄이는 거리")]
    [SerializeField] private float dropHandForwardOffset = 0.15f;

    [Tooltip("드랍 시 손 위치에서 위로 살짝 올려 겹침을 줄이는 거리")]
    [SerializeField] private float dropHandUpOffset = 0.05f;

    [Header("Debug")]
    [SerializeField] private bool enableDebugLogs = false;

    private readonly NetworkVariable<NetworkObjectReference> _heldItem =
        new NetworkVariable<NetworkObjectReference>(
            default,
            NetworkVariableReadPermission.Everyone,
            NetworkVariableWritePermission.Server
        );

    private bool _ownerMode;
    private bool _pendingAttach;
    private bool _attached;
    private float _pendingStartTime;

    private NetworkObject _heldCache;
    private ItemPickupNetwork _heldPickup;
    private ItemDataSO _heldItemData;
    private WeaponItemDataSO _heldWeaponData;

    private int _cachedWeaponAnimId;
    private Vector3 _cachedLocalPos;
    private Vector3 _cachedLocalEuler;
    private Vector3 _cachedLocalScale;
    private GameObject _cachedEquippedVisualPrefab;
    private bool _hasCachedMeta;
    private bool _useLocalHeldVisual;

    private CharacterController _cc;
    private Animator _anim;

    private GameObject _localHeldVisualInstance;
    private GameObject _localHeldVisualSourcePrefab;
    private Vector3 _lastRequestedHeldWorldPosition;
    private Quaternion _lastRequestedHeldWorldRotation = Quaternion.identity;
    private Vector3 _lastRequestedHeldWorldScale = Vector3.one;
    private bool _hasLastRequestedHeldPose;

    private const float MinSocketLossyScale = 0.0001f;

    public void SetOwnerMode(bool active)
    {
        _ownerMode = active;
    }

    public override void OnNetworkSpawn()
    {
        base.OnNetworkSpawn();

        _cc = GetComponentInParent<CharacterController>();
        _anim = GetComponentInParent<Animator>();

        AutoFindRefs();
        _heldItem.OnValueChanged += OnHeldItemChanged;

        ResolveHeldCache();
        CacheHeldMeta();
        RefreshHeldPresentation();
    }

    public override void OnNetworkDespawn()
    {
        _heldItem.OnValueChanged -= OnHeldItemChanged;
        DestroyLocalHeldVisual();
        base.OnNetworkDespawn();
    }

    private void AutoFindRefs()
    {
        if (ownerCamera == null)
            ownerCamera = GetComponentInParent<Camera>();

        if (_anim == null)
            _anim = GetComponentInParent<Animator>();

        if (_anim != null && _anim.isHuman)
        {
            if (rightHandBone == null)
                rightHandBone = _anim.GetBoneTransform(HumanBodyBones.RightHand);

            if (leftHandBone == null)
                leftHandBone = _anim.GetBoneTransform(HumanBodyBones.LeftHand);
        }
    }

    private void OnHeldItemChanged(NetworkObjectReference previousValue, NetworkObjectReference newValue)
    {
        RestorePreviousWorldItemVisual(previousValue);

        ClearHeldRuntimeCache();
        ResetHeldMetaCache();

        _pendingAttach = false;
        _attached = false;
        _pendingStartTime = Time.time;
        _hasLastRequestedHeldPose = false;

        DestroyLocalHeldVisual();

        ResolveHeldCache();
        CacheHeldMeta();
        RefreshHeldPresentation();
    }

    private void Update()
    {
        if (_pendingAttach && !_attached)
        {
            if (Time.time - _pendingStartTime >= pickupPendingTime || TryApplyHeldWorldPose(false))
                ForceAttach();
        }
    }

    private void LateUpdate()
    {
        if (!_attached) return;
        TryApplyHeldWorldPose(false);
    }

    public bool HasHeldItem()
    {
        return ResolveHeldCache();
    }

    public WeaponItemDataSO GetHeldWeaponData()
    {
        if (!ResolveHeldCache())
        {
            ClearHeldRuntimeCache();
            ResetHeldMetaCache();
            return null;
        }

        if (_heldPickup == null)
        {
            ResetHeldMetaCache();
            return null;
        }

        if (_heldItemData == null && _heldWeaponData == null)
            CacheHeldMeta();

        return _heldWeaponData;
    }

    public bool TryFindPickupTarget(out NetworkObjectReference target)
    {
        target = default;

        if (!_ownerMode) return false;
        if (ownerCamera == null) return false;
        if (HasHeldItem()) return false;

        Ray ray = new Ray(ownerCamera.transform.position, ownerCamera.transform.forward);
        if (!Physics.Raycast(ray, out RaycastHit hit, pickupDistance, pickupMask, QueryTriggerInteraction.Ignore))
            return false;

        NetworkObject netObj = hit.collider.GetComponentInParent<NetworkObject>();
        if (netObj == null || !netObj.IsSpawned) return false;

        target = netObj;
        return true;
    }

    public bool ServerTryPickup(NetworkObjectReference target)
    {
        if (!IsServer) return false;
        if (ResolveHeldCache()) return false;

        if (!target.TryGet(out NetworkObject netObj)) return false;
        if (netObj == null || !netObj.IsSpawned) return false;

        netObj.ChangeOwnership(OwnerClientId);

        // 먼저 캐시를 임시 계산해서 local visual 가능 여부를 판정
        ItemPickupNetwork pickup = netObj.GetComponent<ItemPickupNetwork>();
        WeaponItemDataSO weaponData = pickup != null ? pickup.GetWeaponData() : null;
        bool useLocalVisual = ShouldUseLocalHeldVisual(weaponData);

        SetHeldPhysics(netObj, true);
        SetWorldItemPresentationState(netObj, true);

        _heldItem.Value = target;

        if (!useLocalVisual && disableCharacterControllerWhilePickingUp && _cc != null && _cc.enabled)
            _cc.enabled = false;

        ResolveHeldCache();
        CacheHeldMeta();
        RefreshHeldPresentation();

        Log($"[PlayerInteract] ServerTryPickup -> {netObj.name}, localVisual:{useLocalVisual}");
        return true;
    }

    public void ServerTryDrop()
    {
        if (!IsServer) return;
        if (!ResolveHeldCache()) return;

        NetworkObject netObj = _heldCache;
        bool usedLocalVisual = _useLocalHeldVisual;

        _attached = false;
        _pendingAttach = false;
        _hasLastRequestedHeldPose = false;

        if (!_hasCachedMeta)
            CacheHeldMeta();

        if (TryGetHandWorldPose(out Vector3 handPos, out Quaternion handRot))
        {
            Vector3 dropPos = handPos + transform.forward * dropHandForwardOffset + Vector3.up * dropHandUpOffset;
            ApplyWorldItemPose(netObj, dropPos, handRot, GetDefaultWorldItemScale());
        }
        else
        {
            Vector3 dropPos = transform.position + transform.forward * 1.2f + Vector3.up * 1.0f;
            ApplyWorldItemPose(netObj, dropPos, Quaternion.identity, GetDefaultWorldItemScale());
        }

        SetWorldItemPresentationState(netObj, true);
        SetHeldPhysics(netObj, false);

        Rigidbody rb = netObj.GetComponent<Rigidbody>();
        if (rb != null)
        {
            Vector3 force = transform.forward * throwForwardForce + Vector3.up * throwUpForce;
            rb.AddForce(force, ForceMode.Impulse);
        }

        if (NetworkManager != null)
            netObj.ChangeOwnership(NetworkManager.ServerClientId);

        _heldItem.Value = default;

        if (_cc != null && !_cc.enabled)
            _cc.enabled = true;

        Log($"[PlayerInteract] ServerTryDrop -> {netObj.name}, localVisual:{usedLocalVisual}");
    }

    public int GetCurrentWeaponAnimID()
    {
        if (!ResolveHeldCache()) return 0;
        if (!_hasCachedMeta) CacheHeldMeta();
        return _hasCachedMeta ? _cachedWeaponAnimId : 0;
    }

    public void AnimEvent_AttachHeldItem()
    {
        if (_useLocalHeldVisual)
        {
            RefreshHeldPresentation();
            return;
        }

        if (!IsServer) return;
        ForceAttach();
    }

    private void ForceAttach()
    {
        if (!ResolveHeldCache()) return;

        _pendingAttach = false;

        if (_cc != null && !_cc.enabled)
            _cc.enabled = true;

        _attached = TryApplyHeldWorldPose(true);

        if (!_attached)
        {
            _pendingAttach = true;
            _pendingStartTime = Time.time;
        }
    }

    private bool ResolveHeldCache()
    {
        if (_heldCache != null && _heldCache.IsSpawned)
            return true;

        if (_heldItem.Value.TryGet(out NetworkObject netObj))
        {
            _heldCache = netObj;
            _heldPickup = _heldCache != null ? _heldCache.GetComponent<ItemPickupNetwork>() : null;
            _heldItemData = _heldPickup != null ? _heldPickup.itemData : null;
            _heldWeaponData = _heldItemData as WeaponItemDataSO;
            return _heldCache != null && _heldCache.IsSpawned;
        }

        ClearHeldRuntimeCache();
        _hasLastRequestedHeldPose = false;
        return false;
    }

    private bool TryGetHandWorldPose(out Vector3 pos, out Quaternion rot)
    {
        pos = Vector3.zero;
        rot = Quaternion.identity;

        Transform handSocket = GetTargetHandSocket();
        if (handSocket == null) return false;

        Vector3 localPos = _hasCachedMeta ? _cachedLocalPos : defaultHeldLocalPosition;
        Vector3 localEuler = _hasCachedMeta ? _cachedLocalEuler : defaultHeldLocalEulerAngles;

        pos = handSocket.TransformPoint(localPos);
        rot = handSocket.rotation * Quaternion.Euler(localEuler);
        return true;
    }

    private Transform GetTargetHandSocket()
    {
        AutoFindRefs();

        Transform humanoidRightHand = GetHumanoidHandBone(HumanBodyBones.RightHand);
        Transform humanoidLeftHand = GetHumanoidHandBone(HumanBodyBones.LeftHand);

        if (_heldWeaponData != null && _heldWeaponData.hand == WeaponHand.Left)
        {
            if (IsValidHandSocket(leftHandBone))
                return leftHandBone;

            if (IsValidHandSocket(humanoidLeftHand))
                return humanoidLeftHand;
        }

        if (IsValidHandSocket(rightHandBone))
            return rightHandBone;

        if (IsValidHandSocket(humanoidRightHand))
            return humanoidRightHand;

        if (IsValidHandSocket(leftHandBone))
            return leftHandBone;

        if (IsValidHandSocket(humanoidLeftHand))
            return humanoidLeftHand;

        return null;
    }

    private void SetHeldPhysics(NetworkObject netObj, bool held)
    {
        Rigidbody rb = netObj.GetComponent<Rigidbody>();
        if (rb != null)
        {
            if (held)
            {
                if (!rb.isKinematic)
                {
                    rb.linearVelocity = Vector3.zero;
                    rb.angularVelocity = Vector3.zero;
                }

                rb.isKinematic = true;
                rb.detectCollisions = false;
                rb.Sleep();
            }
            else
            {
                rb.isKinematic = false;
                rb.detectCollisions = true;
                rb.linearVelocity = Vector3.zero;
                rb.angularVelocity = Vector3.zero;
                rb.WakeUp();
            }
        }

        Collider[] cols = netObj.GetComponentsInChildren<Collider>(true);
        for (int i = 0; i < cols.Length; i++)
            cols[i].enabled = !held;
    }

    private void SetWorldItemPresentationState(NetworkObject netObj, bool visible)
    {
        if (netObj == null) return;

        ItemPickupNetwork pickup = netObj.GetComponent<ItemPickupNetwork>();
        if (pickup != null)
            pickup.SetWorldVisualVisibleServer(visible);
        else
            SetRendererEnabled(netObj, visible);

        Canvas[] canvases = netObj.GetComponentsInChildren<Canvas>(true);
        for (int i = 0; i < canvases.Length; i++)
        {
            if (canvases[i] != null)
                canvases[i].enabled = visible;
        }
    }

    private void RestorePreviousWorldItemVisual(NetworkObjectReference previousValue)
    {
        if (!previousValue.TryGet(out NetworkObject prevNetObj))
            return;

        if (prevNetObj == null || !prevNetObj.IsSpawned)
            return;

        SetWorldItemPresentationState(prevNetObj, true);
    }

    private void CacheHeldMeta()
    {
        ResetHeldMetaCache();

        if (!ResolveHeldCache()) return;
        if (_heldPickup == null) return;

        _heldItemData = _heldPickup.itemData;
        _heldWeaponData = _heldItemData as WeaponItemDataSO;
        if (_heldWeaponData == null) return;

        _cachedWeaponAnimId = _heldWeaponData.weaponAnimID;
        _cachedLocalPos = _heldWeaponData.equippedLocalPosition;
        _cachedLocalEuler = _heldWeaponData.equippedLocalEulerAngles;
        _cachedLocalScale = _heldWeaponData.equippedLocalScale == Vector3.zero ? Vector3.one : _heldWeaponData.equippedLocalScale;
        _cachedEquippedVisualPrefab = _heldWeaponData.equippedModelPrefab;
        _hasCachedMeta = true;
        _useLocalHeldVisual = false;
    }

    private void ClearHeldRuntimeCache()
    {
        _heldCache = null;
        _heldPickup = null;
        _heldItemData = null;
        _heldWeaponData = null;
        _hasLastRequestedHeldPose = false;
    }

    private void ResetHeldMetaCache()
    {
        _hasCachedMeta = false;
        _heldItemData = null;
        _heldWeaponData = null;
        _cachedWeaponAnimId = 0;
        _cachedLocalPos = defaultHeldLocalPosition;
        _cachedLocalEuler = defaultHeldLocalEulerAngles;
        _cachedLocalScale = defaultHeldLocalScale;
        _cachedEquippedVisualPrefab = null;
        _useLocalHeldVisual = false;
    }

    private bool ShouldUseLocalHeldVisual(WeaponItemDataSO weaponData)
    {
        return false;
    }

    private void RefreshHeldPresentation()
    {
        if (!ResolveHeldCache())
        {
            DestroyLocalHeldVisual();
            ApplyHeldPresentationTransition(false, false, false);
            return;
        }

        DestroyLocalHeldVisual();
        ApplyHeldPresentationTransition(true, true, false);
    }

    private bool EnsureLocalHeldVisual()
    {
        if (!_useLocalHeldVisual)
            return false;

        if (_cachedEquippedVisualPrefab == null)
        {
            Log("[PlayerInteract] No equippedModelPrefab assigned.");
            return false;
        }

        Transform handSocket = GetTargetHandSocket();
        if (handSocket == null)
        {
            Log("[PlayerInteract] Hand socket not found.");
            return false;
        }

        if (_localHeldVisualInstance == null || _localHeldVisualSourcePrefab != _cachedEquippedVisualPrefab)
        {
            DestroyLocalHeldVisual();
            _localHeldVisualInstance = Instantiate(_cachedEquippedVisualPrefab, handSocket);
            _localHeldVisualSourcePrefab = _cachedEquippedVisualPrefab;
            Log($"[PlayerInteract] Spawn local held visual: {_cachedEquippedVisualPrefab.name}");
        }

        UpdateLocalHeldVisualTransform();
        return _localHeldVisualInstance != null;
    }

    private void UpdateLocalHeldVisualTransform()
    {
        if (_localHeldVisualInstance == null)
            return;

        Transform handSocket = GetTargetHandSocket();
        if (handSocket == null)
            return;

        if (_localHeldVisualInstance.transform.parent != handSocket)
            _localHeldVisualInstance.transform.SetParent(handSocket, false);

        _localHeldVisualInstance.transform.localPosition = _cachedLocalPos;
        _localHeldVisualInstance.transform.localRotation = Quaternion.Euler(_cachedLocalEuler);
        _localHeldVisualInstance.transform.localScale = SanitizeVisualScale(_cachedLocalScale);
    }

    private bool TryAttachWorldHeldItemImmediate()
    {
        return TryApplyHeldWorldPose(true);
    }

    private void ApplyHeldPresentationTransition(bool hasHeldItem, bool worldVisible, bool allowWorldAttachFallback)
    {
        if (!hasHeldItem || _heldCache == null)
        {
            _pendingAttach = false;
            _attached = false;
            return;
        }

        SetWorldItemPresentationState(_heldCache, worldVisible);
        _attached = TryAttachWorldHeldItemImmediate();
        _pendingAttach = !_attached;

        if (_pendingAttach)
            _pendingStartTime = Time.time;

        if (_cc != null && !_cc.enabled)
            _cc.enabled = true;
    }

    private void SetRendererEnabled(NetworkObject netObj, bool visible)
    {
        Renderer[] renderers = netObj.GetComponentsInChildren<Renderer>(true);
        for (int i = 0; i < renderers.Length; i++)
        {
            if (renderers[i] != null)
                renderers[i].enabled = visible;
        }
    }

    private Transform GetHumanoidHandBone(HumanBodyBones handBone)
    {
        if (_anim == null || !_anim.isHuman)
            return null;

        return _anim.GetBoneTransform(handBone);
    }

    private bool IsValidHandSocket(Transform handSocket)
    {
        if (handSocket == null)
            return false;

        Vector3 lossyScale = handSocket.lossyScale;
        if (!IsFinite(lossyScale.x) || !IsFinite(lossyScale.y) || !IsFinite(lossyScale.z))
            return false;

        return Mathf.Abs(lossyScale.x) > MinSocketLossyScale
            && Mathf.Abs(lossyScale.y) > MinSocketLossyScale
            && Mathf.Abs(lossyScale.z) > MinSocketLossyScale;
    }

    private Vector3 SanitizeVisualScale(Vector3 scale)
    {
        if (scale == Vector3.zero)
            return Vector3.one;

        if (!IsFinite(scale.x) || Mathf.Approximately(scale.x, 0f))
            scale.x = 1f;

        if (!IsFinite(scale.y) || Mathf.Approximately(scale.y, 0f))
            scale.y = 1f;

        if (!IsFinite(scale.z) || Mathf.Approximately(scale.z, 0f))
            scale.z = 1f;

        return scale;
    }

    private bool TryApplyHeldWorldPose(bool syncNetworkTransform)
    {
        if (!ResolveHeldCache())
            return false;

        if (!TryGetHandWorldPose(out Vector3 handPos, out Quaternion handRot))
            return false;

        Vector3 heldWorldScale = GetHeldWorldScale();
        bool isStableHeld = _attached && !_pendingAttach;

        if (!syncNetworkTransform && isStableHeld && _hasLastRequestedHeldPose)
        {
            float positionDeltaSqr = (_lastRequestedHeldWorldPosition - handPos).sqrMagnitude;
            float rotationDelta = Quaternion.Angle(_lastRequestedHeldWorldRotation, handRot);
            float scaleDeltaSqr = (_lastRequestedHeldWorldScale - heldWorldScale).sqrMagnitude;

            if (positionDeltaSqr <= RequestedPosePositionEpsilon * RequestedPosePositionEpsilon &&
                rotationDelta <= RequestedPoseRotationEpsilon &&
                scaleDeltaSqr <= RequestedPoseScaleEpsilon * RequestedPoseScaleEpsilon)
            {
                return true;
            }
        }

        ApplyWorldItemPose(_heldCache, handPos, handRot, heldWorldScale, syncNetworkTransform);
        _lastRequestedHeldWorldPosition = handPos;
        _lastRequestedHeldWorldRotation = handRot;
        _lastRequestedHeldWorldScale = heldWorldScale;
        _hasLastRequestedHeldPose = true;
        return true;
    }

    private void ApplyWorldItemPose(NetworkObject netObj, Vector3 worldPos, Quaternion worldRot, Vector3 worldScale, bool syncNetworkTransform = true)
    {
        if (netObj == null)
            return;

        ItemPickupNetwork pickup = netObj.GetComponent<ItemPickupNetwork>();
        if (pickup != null)
        {
            pickup.ApplyPose(worldPos, worldRot, worldScale, syncNetworkTransform);
            return;
        }

        netObj.transform.SetPositionAndRotation(worldPos, worldRot);
        netObj.transform.localScale = worldScale;
    }

    private Vector3 GetHeldWorldScale()
    {
        return SanitizeVisualScale(_hasCachedMeta ? _cachedLocalScale : defaultHeldLocalScale);
    }

    private Vector3 GetDefaultWorldItemScale()
    {
        if (_heldPickup != null)
            return SanitizeVisualScale(_heldPickup.GetDefaultLocalScale());

        if (_heldCache != null)
            return SanitizeVisualScale(_heldCache.transform.localScale);

        return Vector3.one;
    }

    private bool IsFinite(float value)
    {
        return !float.IsNaN(value) && !float.IsInfinity(value);
    }

    private void DestroyLocalHeldVisual()
    {
        if (_localHeldVisualInstance == null)
            return;

        if (Application.isPlaying)
            Destroy(_localHeldVisualInstance);
        else
            DestroyImmediate(_localHeldVisualInstance);

        _localHeldVisualInstance = null;
        _localHeldVisualSourcePrefab = null;
    }

    private void Log(string message)
    {
        if (!enableDebugLogs) return;
        Debug.Log(message);
    }

#if UNITY_EDITOR
    private void OnValidate()
    {
        AutoFindRefs();
    }
#endif
}
